import 'package:flutter/material.dart';

class MyColors {
  static const background = Color(0xffF6F4EB);
  static const col1 = Color(0xff91c8e4);
  static const col2 = Color(0xff749BC2);
  static const col3 = Color(0xff4682A9);
}
